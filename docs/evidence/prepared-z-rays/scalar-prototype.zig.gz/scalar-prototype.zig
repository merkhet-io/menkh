//! Shared, immutable coefficients for conic rejection along world-Z rays.
//! Point-dependent arithmetic keeps the scalar solver's evaluation order.
const std = @import("std");
const e = @import("engine.zig");
const d = @import("raydexel.zig");
const s = @import("profile_sweep.zig");
const Side = struct { slope: f64, intercept: f64, margin: f64, velocity: f64, qa: f64 };
pub const Ray = struct {
    base: e.V,
    axis: e.V,
    cap_offset: f64,
    length: f64,
    vz: f64,
    vr: e.V,
    sides: []const Side,
    fn init(profile: d.Profile, base: e.V, axis: e.V, cap_offset: f64, offset: f64, radial_half: f64, axial_half: f64, directional: bool, storage: []Side) Ray {
        const vz = e.dot(.{ 0, 0, 1 }, axis);
        const vr = e.sub(.{ 0, 0, 1 }, e.scale(axis, vz));
        const aa = e.dot(vr, vr);
        for (storage, profile.sides) |*prepared, side| {
            const v = side.slope * vz;
            const margin = if (directional) offset * side.normal_length + radial_half + @abs(side.slope) * axial_half else offset * side.normal_length;
            prepared.* = .{ .slope = side.slope, .intercept = side.intercept, .margin = margin, .velocity = v, .qa = aa - v * v };
        }
        return .{ .base = base, .axis = axis, .cap_offset = cap_offset, .length = profile.length, .vz = vz, .vr = vr, .sides = storage };
    }
    pub fn intersect(self: Ray, x: f64, y: f64, limits: d.Interval, retained: []const d.Interval) !?d.Interval {
        const q = e.sub(.{ x, y, 0 }, self.base);
        const z = e.dot(q, self.axis);
        var interval = d.positive(limits, self.vz, z + self.cap_offset) orelse return null;
        interval = d.positive(interval, -self.vz, self.length + self.cap_offset - z) orelse return null;
        var active = d.trimMaterial(retained, interval);
        if (active.len == 0) return null;
        const qr = e.sub(q, e.scale(self.axis, z));
        const bb = 2 * e.dot(qr, self.vr);
        const cc = e.dot(qr, qr);
        for (self.sides) |side| {
            const r = side.intercept + side.slope * z + side.margin;
            interval = d.positive(interval, side.velocity, r) orelse return null;
            interval = (try d.quadratic(interval, side.qa, bb - 2 * r * side.velocity, cc - r * r)) orelse return null;
            active = d.trimMaterial(active, interval);
            if (active.len == 0) return null;
        }
        return interval;
    }
};
pub const Scene = struct {
    allocator: std.mem.Allocator,
    rays: []Ray,
    sides: []Side,
    node_count: usize,
    pub fn init(a: std.mem.Allocator, profile: d.Profile, sweeps: []const s.Sweep, tree: d.Tree) !Scene {
        const count = try std.math.add(usize, tree.nodes.items.len, sweeps.len);
        const rays = try a.alloc(Ray, count);
        errdefer a.free(rays);
        const sides = try a.alloc(Side, try std.math.mul(usize, count, profile.sides.len));
        errdefer a.free(sides);
        for (tree.nodes.items, 0..) |n, i| {
            const pose = tree.poses[n.anchorIndex()];
            const offset = @max(@as(f64, 0), n.envelope_offset);
            rays[i] = Ray.init(profile, pose.base, pose.axis, offset, offset, 0, 0, false, sides[i * profile.sides.len ..][0..profile.sides.len]);
        }
        for (sweeps, tree.nodes.items.len..) |cut, i| {
            rays[i] = Ray.init(profile, cut.envelope_midpoint, cut.start.axis, cut.start.offset + cut.envelope_axial_half + cut.envelope_guard, cut.start.offset + cut.envelope_guard, cut.envelope_radial_half, cut.envelope_axial_half, true, sides[i * profile.sides.len ..][0..profile.sides.len]);
        }
        return .{ .allocator = a, .rays = rays, .sides = sides, .node_count = tree.nodes.items.len };
    }
    pub fn deinit(self: *Scene) void {
        self.allocator.free(self.rays);
        self.allocator.free(self.sides);
    }
    pub fn bytes(self: Scene) usize {
        return self.rays.len * @sizeOf(Ray) + self.sides.len * @sizeOf(Side);
    }
    pub fn node(self: Scene, index: usize) Ray {
        return self.rays[index];
    }
    pub fn sweep(self: Scene, index: usize) Ray {
        return self.rays[self.node_count + index];
    }
};
